
public class EmpleadoMaquina extends Empleado{
	
	private int idEmpleadoMaquina;
	private Maquina maquina;

	public EmpleadoMaquina(int idEmpleadoMaquina, Maquina maquina) {
		this.idEmpleadoMaquina = idEmpleadoMaquina;
		this.maquina = maquina;
	}
	
	public Maquina getMaquina() {
		return maquina;
	}

	public void setMaquina(Maquina maquina) {
		this.maquina = maquina;
	}

	public int getIdEmpleadoMaquina() {
		return idEmpleadoMaquina;
	}

	public void setIdEmpleadoMaquina(int idEmpleadoMaquina) {
		this.idEmpleadoMaquina = idEmpleadoMaquina;
	}
	
	public void encenderMaquina (Maquina maquina) {
		maquina.encender();
	}
		
	public void apagarMaquina (Maquina maquina) {
		maquina.apagar();
	}	
	
}
